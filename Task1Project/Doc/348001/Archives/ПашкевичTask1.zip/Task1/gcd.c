#include <stdio.h>
#include <time.h>

// Наивный алгоритм НОД (обычное деление)
long long gcd_naive(long long a, long long b) {
    long long gcd = 1;
    for (long long d = 2; d <= (a > b ? a : b); ++d) {
        if (a % d == 0 && b % d == 0) {
            gcd = d;
        }
    }
    return gcd;
}

// Алгоритм Евклида для НОД
long long gcd_euclidean(long long a, long long b) {
    if (b == 0)
        return a;
    return gcd_euclidean(b, a % b);
}

// Измерение времени для наивного алгоритма НОД
void measure_time_naive(long long a, long long b) {
    clock_t start, end;
    double cpu_time_used;
    
    start = clock();
    long long gcd = gcd_naive(a, b);
    end = clock();
    
    cpu_time_used = ((double) (end - start)) / CLOCKS_PER_SEC;
    printf("Naive GCD - A: %lld, B: %lld, GCD: %lld, Time: %f seconds\n", a, b, gcd, cpu_time_used);
}

// Измерение времени для алгоритма Евклида НОД
void measure_time_euclidean(long long a, long long b) {
    clock_t start, end;
    double cpu_time_used;
    
    start = clock();
    long long gcd = gcd_euclidean(a, b);
    end = clock();
    
    cpu_time_used = ((double) (end - start)) / CLOCKS_PER_SEC;
    printf("Euclidean GCD - A: %lld, B: %lld, GCD: %lld, Time: %f seconds\n", a, b, gcd, cpu_time_used);
}

int main() {
    long long numbers[4][2] = {
        {8723462536745223LL, 765412221883LL},
        {2973948729384212LL, 87268364827634LL},
        {1098304287349821LL, 125367765723LL},
        {2987349872934234LL, 78238486224LL}
    };

    // Измерение времени для наивного алгоритма
    for (int i = 0; i < 4; i++) {
        measure_time_naive(numbers[i][0], numbers[i][1]);
    }

    // Измерение времени для алгоритма Евклида
    for (int i = 0; i < 4; i++) {
        measure_time_euclidean(numbers[i][0], numbers[i][1]);
    }
    
    return 0;
}
