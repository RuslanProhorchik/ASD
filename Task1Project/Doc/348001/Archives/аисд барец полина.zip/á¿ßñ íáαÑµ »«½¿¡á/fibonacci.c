#include <stdio.h>
#include <stdlib.h>
#include <time.h>

unsigned long long FibRec(num) {
    if (num <= 1) {
        return 1;
    } else if (num == 2) {
        return 1;
    } else {
        return FibRec(num - 1) + FibRec(num - 2);
  }
}
unsigned long long FibArr(num) {
    unsigned long long *F = (unsigned long long *)malloc(num * sizeof(unsigned long long));
    if (num >= 1) {
        F[0] = 1;
    }
    if (num >= 2) {
        F[1] = 1;
    }
    for (int j = 2; j < num; j++) {
        F[j] = F[j - 1] + F[j - 2];
    }
    unsigned long long result = F[num - 1];
    free(F);
    return result;
        }

int main()
{
    clock_t t1,t2;
    double d1,d2;
    unsigned long long result_arr, result_rec;
    int i;
    int n[45];
    for (i = 0; i < 45; i++)
        n[i] = i + 1;
    for (i = 0;i < 45;i++){
        t1 = clock();
        result_arr = FibArr(n[i]);
        t1 = clock() - t1;
        d1 = ((double)t1)/CLOCKS_PER_SEC;

        t2 = clock();
        result_rec = FibRec(n[i]);
        t2 = clock() - t2;
        d2 = ((double)t2)/CLOCKS_PER_SEC;

        printf("N: %d   Array: %d (TIME: %f)    Recursive: %d (TIME: %f) \n", n[i], result_arr , d1, result_rec, d2);
    }
    return 0;
}
