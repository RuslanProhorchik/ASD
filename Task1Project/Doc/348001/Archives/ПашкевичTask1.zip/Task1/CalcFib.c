
#include <stdio.h>
#include <time.h>

// Рекурсивная функция Фибоначчи
long long fibonacci_recursive(int n) {
    if (n <= 1) return n;
    return fibonacci_recursive(n - 1) + fibonacci_recursive(n - 2);
}

// Измерение времени для рекурсивной функции
void measure_time_recursive(int n) {
    clock_t start, end;
    double cpu_time_used;
    
    start = clock();
    fibonacci_recursive(n);
    end = clock();
    
    cpu_time_used = ((double) (end - start)) / CLOCKS_PER_SEC;
    printf("Recursive - N: %d, Time: %f seconds\n", n, cpu_time_used);
}

// Функция Фибоначчи с использованием массива
long long fibonacci_array(int n) {
    if (n <= 1) return n;
    
    long long fibonacci[n + 1];
    fibonacci[0] = 0;
    fibonacci[1] = 1;
    
    for (int i = 2; i <= n; i++) {
        fibonacci[i] = fibonacci[i - 1] + fibonacci[i - 2];
    }
    
    return fibonacci[n];
}

// Измерение времени для функции с массивом
void measure_time_array(int n) {
    clock_t start, end;
    double cpu_time_used;
    
    start = clock();
    fibonacci_array(n);
    end = clock();
    
    cpu_time_used = ((double) (end - start)) / CLOCKS_PER_SEC;
    printf("Array-based - N: %d, Time: %f seconds\n", n, cpu_time_used);
}

int main() {
    int N1_values[5]; // Массив для хранения значений N
    int N2_values[5];
    
    // Ввод значений N пользователем
    printf("Введите 5 значений N1 (например, 100 250 500 1000 5000):\n");
    for (int i = 0; i < 5; i++) {
        scanf("%d", &N1_values[i]);
    }
    printf("Введите 5 значений N2 (например, 100 250 500 1000 5000):\n");
     for (int i = 0; i < 5; i++) {
        scanf("%d", &N2_values[i]);
    }
    // Измерение времени для рекурсивного алгоритма
    for (int i = 0; i < 5; i++) {
        measure_time_recursive(N1_values[i]);
    }
    
    // Измерение времени для алгоритма с массивом
    for (int i = 0; i < 5; i++) {
        measure_time_array(N2_values[i]);
    }
    
    return 0;
}
