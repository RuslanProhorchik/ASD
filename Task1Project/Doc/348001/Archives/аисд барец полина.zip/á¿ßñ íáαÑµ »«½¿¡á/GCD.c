#include <stdio.h>
#include <time.h>
unsigned long long gcd_naive(unsigned long long a, unsigned long long b) {
    int gcd = 1;
    for (int i = 1; i <= a && i <= b; i++) {
        if (a % i == 0 && b % i == 0) {
            gcd = i;
        }
    }
    return gcd;
}

unsigned long long gcd_euclid(unsigned long long a, unsigned long long b) {
    if (a == 0) return b;
    if (b == 0) return a;
    return gcd_euclid(b, a % b);
}

int main() {
    double d;
    clock_t t;
    unsigned long long result_naive, result_euclid;
    unsigned long long num1[4] = {8723462536745223,2973948729384212,1098304287349821,2987349872934234};
    unsigned long long num2[4] = {765412221883,87268364827634,125367765723,78238486224};

    for (int i = 0; i < 4; i++){
    printf("For %llu & %llu\n", num1[i], num2[i]);

    t = clock();
    result_naive = gcd_naive(num1[i], num2[i]);
    t = clock() - t;
    d = ((double)t)/CLOCKS_PER_SEC;
    printf("Naive: %d (TIME: %f s)  ,  ", result_naive, d);

    t = clock();
    result_euclid = gcd_euclid(num1[i], num2[i]);
    t = clock() - t;
    d = ((double)t)/CLOCKS_PER_SEC;
    printf("Euclid: %d (TIME: %f s)    \n", result_euclid, d);
    }

    return 0;
}
